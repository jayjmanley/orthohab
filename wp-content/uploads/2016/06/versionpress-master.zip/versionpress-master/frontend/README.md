# VersionPress GUI #

* Development environment setup etc: http://wiki.agilio.cz/versionpress:dokumentace
