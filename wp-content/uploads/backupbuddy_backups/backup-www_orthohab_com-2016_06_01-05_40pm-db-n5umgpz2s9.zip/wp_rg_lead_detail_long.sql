CREATE TABLE `wp_rg_lead_detail_long` (  `lead_detail_id` bigint(20) unsigned NOT NULL,  `value` longtext COLLATE utf8mb4_unicode_ci,  PRIMARY KEY (`lead_detail_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_rg_lead_detail_long` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_rg_lead_detail_long` ENABLE KEYS */;
