CREATE TABLE `wp_term_relationships` (  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',  `term_order` int(11) NOT NULL DEFAULT '0',  PRIMARY KEY (`object_id`,`term_taxonomy_id`),  KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES('28', '2', '0');
INSERT INTO `wp_term_relationships` VALUES('70', '3', '0');
INSERT INTO `wp_term_relationships` VALUES('71', '3', '0');
INSERT INTO `wp_term_relationships` VALUES('72', '3', '0');
INSERT INTO `wp_term_relationships` VALUES('118', '3', '0');
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
